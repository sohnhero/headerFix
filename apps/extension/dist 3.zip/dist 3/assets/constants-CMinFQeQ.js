const e="servicenow.aggregateLabels",a="servicenow-pivot-data-captured";export{a as I,e as S};
