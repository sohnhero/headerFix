import{r as o,j as e,R as y,a as g}from"./index-AEklJJXT.js";import{S as r}from"./constants-CMinFQeQ.js";/**
 * @license lucide-react v0.300.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var j={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.300.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=t=>t.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().trim(),i=(t,n)=>{const d=o.forwardRef(({color:x="currentColor",size:l=24,strokeWidth:s=2,absoluteStrokeWidth:a,className:c="",children:m,...p},h)=>o.createElement("svg",{ref:h,...j,width:l,height:l,stroke:x,strokeWidth:a?Number(s)*24/Number(l):s,className:["lucide",`lucide-${N(t)}`,c].join(" "),...p},[...n.map(([u,f])=>o.createElement(u,f)),...Array.isArray(m)?m:[m]]));return d.displayName=`${t}`,d};/**
 * @license lucide-react v0.300.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=i("CheckCircle2",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.300.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=i("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-react v0.300.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=i("ExternalLink",[["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}],["polyline",{points:"15 3 21 3 21 9",key:"mznyad"}],["line",{x1:"10",x2:"21",y1:"14",y2:"3",key:"18c3s4"}]]);/**
 * @license lucide-react v0.300.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=i("Loader2",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);/**
 * @license lucide-react v0.300.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=i("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);function E(){const[t,n]=o.useState(null);o.useEffect(()=>{chrome.storage.local.get([r],a=>{a[r]&&n(a[r])});const s=(a,c)=>{c==="local"&&a[r]&&n(a[r].newValue)};return chrome.storage.onChanged.addListener(s),()=>chrome.storage.onChanged.removeListener(s)},[]);const d=async()=>{t&&await navigator.clipboard.writeText(JSON.stringify(t.labels,null,2))},x=()=>{chrome.storage.local.remove([r]),n(null)},l=()=>{let a="https://header-fix-extension.vercel.app/dashboard";if(t&&t.labels){const c=encodeURIComponent(JSON.stringify(t.labels));a+=`#data=${c}`}chrome.tabs.create({url:a})};return e.jsxs("div",{className:"w-[400px] min-h-[300px] bg-background text-foreground p-4 flex flex-col font-sans",children:[e.jsxs("div",{className:"flex items-center justify-between mb-6",children:[e.jsx("h1",{className:"text-lg font-semibold tracking-tight",children:"Pivot Header Fixer"}),e.jsx("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"p-2 hover:bg-secondary rounded-full transition-colors",children:e.jsx(C,{className:"w-4 h-4 text-muted-foreground"})})]}),t?e.jsxs("div",{className:"flex-1 flex flex-col space-y-6",children:[e.jsxs("div",{className:"bg-primary/10 border border-primary/20 rounded-xl p-4 flex items-start space-x-3",children:[e.jsx(b,{className:"w-5 h-5 text-primary shrink-0 mt-0.5"}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium text-primary",children:"Successfully Captured!"}),e.jsxs("p",{className:"text-sm text-primary/80 mt-0.5",children:["Found ",t.labels.length," metric headers."]})]})]}),e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex flex-col space-y-1",children:[e.jsx("span",{className:"text-xs font-medium text-muted-foreground uppercase tracking-wider",children:"Instance"}),e.jsx("span",{className:"text-sm truncate",children:t.instanceUrl})]}),e.jsxs("div",{className:"flex flex-col space-y-1",children:[e.jsx("span",{className:"text-xs font-medium text-muted-foreground uppercase tracking-wider",children:"Dashboard"}),e.jsx("span",{className:"text-sm truncate",children:t.dashboardTitle})]}),e.jsxs("div",{className:"flex flex-col space-y-1",children:[e.jsx("span",{className:"text-xs font-medium text-muted-foreground uppercase tracking-wider",children:"Captured At"}),e.jsx("span",{className:"text-sm",children:new Date(t.captureDate).toLocaleString()})]})]}),e.jsxs("div",{className:"mt-auto grid grid-cols-2 gap-2 pt-4",children:[e.jsxs("button",{onClick:d,className:"flex items-center justify-center space-x-2 py-2 px-4 rounded-lg bg-secondary hover:bg-secondary/80 text-secondary-foreground text-sm font-medium transition-colors",children:[e.jsx(v,{className:"w-4 h-4"}),e.jsx("span",{children:"Copy JSON"})]}),e.jsxs("button",{onClick:l,className:"flex items-center justify-center space-x-2 py-2 px-4 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground text-sm font-medium transition-colors",children:[e.jsx("span",{children:"Repair Excel"}),e.jsx(k,{className:"w-4 h-4"})]})]}),e.jsx("button",{onClick:x,className:"text-xs text-muted-foreground hover:text-destructive transition-colors text-center",children:"Clear captured data"})]}):e.jsxs("div",{className:"flex-1 flex flex-col items-center justify-center text-center space-y-4",children:[e.jsx("div",{className:"w-12 h-12 rounded-full bg-secondary flex items-center justify-center animate-pulse",children:e.jsx(w,{className:"w-6 h-6 text-primary animate-spin"})}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium",children:"Listening for Exports..."}),e.jsx("p",{className:"text-sm text-muted-foreground mt-1",children:"Open ServiceNow Platform Analytics and export a pivot table to Excel. We'll automatically capture the headers."})]})]})]})}y.createRoot(document.getElementById("root")).render(e.jsx(g.StrictMode,{children:e.jsx(E,{})}));
